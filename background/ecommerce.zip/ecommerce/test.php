<?php

    header("Content-Type: application/json");

    // 1. Get inputs (you can send via POST or GET)
    $amount = isset($_REQUEST['amount']) ? $_REQUEST['amount'] : null;
    $currency = isset($_REQUEST['currency']) ? $_REQUEST['currency'] : null;

    // 2. Validate
    if (!$amount || !$currency) {
        echo json_encode([
            "status" => "failure",
            "message" => "Missing amount or currency"
        ]);
        exit;
    }

    // 3. Prepare Stripe request
    $url = 'https://api.stripe.com/v1/payment_intents';

    $body = http_build_query([
        'amount' => $amount, // Amount in cents
        'currency' => $currency,
        'automatic_payment_methods[enabled]' => 'true',
    ]);

    $headers = [
        'Authorization: Bearer ',
        'Content-Type: application/x-www-form-urlencoded',
    ];

    // 4. Send cURL request
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $body,
        CURLOPT_HTTPHEADER => $headers,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    // 5. Handle result
    if (curl_errno($ch)) {
        echo json_encode([
            "status" => "failure",
            "message" => "cURL Error: " . curl_error($ch)
        ]);
    } else {
        $stripeData = json_decode($response, true);

        if ($httpCode === 200) {
            echo json_encode([
                "status" => "success",
                "data" => $stripeData
            ]);
        } else {
            echo json_encode([
                "status" => "failure",
                "http_code" => $httpCode,
                "error" => $stripeData
            ]);
        }
    }

    curl_close($ch);
?>