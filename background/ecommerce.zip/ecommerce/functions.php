<?php

// ==========================================================
//  Copyright Reserved E commerce
// ==========================================================

define("MB", 1048576);

function filterRequest($requestname)
{
  return  htmlspecialchars(strip_tags($_POST[$requestname]));
}

function returnData($table, $where = null, $values = null)
{
    global $con;
    $data = array();
    $stmt = $con->prepare("SELECT  * FROM $table WHERE   $where ");
    $stmt->execute($values);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    $count  = $stmt->rowCount();
    if ($count > 0){
        return $data;
    } else {
        return null;
    }
}

function getAllData($table, $where = null, $values = null)
{
    global $con;
    $data = array();
    $stmt = $con->prepare("SELECT  * FROM $table WHERE   $where ");
    $stmt->execute($values);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $count  = $stmt->rowCount();
    if ($count > 0){
        echo json_encode(array("status" => "success", "data" => $data));
    } else {
        echo json_encode(array("status" => "failure"));
    }
    return $count;
}

function ReturnAllData($table)
{
    global $con;
    $stmt = $con->prepare("SELECT  * FROM $table ");
    $stmt->execute();
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $count  = $stmt->rowCount();
    if ($count > 0){
        return $data;
    } else {
    return null;
    }
    return null;      
}

function insertData($table, $data, $json = true)
{
    global $con;
    foreach ($data as $field => $v)
        $ins[] = ':' . $field;
    $ins = implode(',', $ins);
    $fields = implode(',', array_keys($data));
    $sql = "INSERT INTO $table ($fields) VALUES ($ins)";

    $stmt = $con->prepare($sql);
    foreach ($data as $f => $v) {
        $stmt->bindValue(':' . $f, $v);
    }
    $stmt->execute();
    $count = $stmt->rowCount();
    if ($json == true) {
    result($count);
  }
    return $count;
}


function updateData($table, $data, $where, $json = true)
{
    global $con;
    $cols = array();
    $vals = array();

    foreach ($data as $key => $val) {
        $vals[] = "$val";
        $cols[] = "`$key` =  ? ";
    }
    $sql = "UPDATE $table SET " . implode(', ', $cols) . " WHERE $where";

    $stmt = $con->prepare($sql);
    $stmt->execute($vals);
    $count = $stmt->rowCount();
    if ($json == true) {
        result($count);
    }
    return $count;
}

function deleteData($table, $where, $json = true)
{
    global $con;
    $stmt = $con->prepare("DELETE FROM $table WHERE $where");
    $stmt->execute();
    $count = $stmt->rowCount();
    if ($json == true) {
        result($count);
    }
    return $count;
}

function imageUpload($imagePath,$imageRequest)
{
    if (isset($imageRequest)) {
        global $msgError;
        $imagename  = rand(1000, 10000) . $_FILES[$imageRequest]['name'];
        $imagetmp   = $_FILES[$imageRequest]['tmp_name'];
        $imagesize  = $_FILES[$imageRequest]['size'];
        $allowExt   = array("jpg", "png", "gif", "mp3", "pdf", "svg");
        $strToArray = explode(".", $imagename);
        $ext        = end($strToArray);
        $ext        = strtolower($ext);
      
        if (!empty($imagename) && !in_array($ext, $allowExt)) {
          $msgError = "EXT";
        }
        if ($imagesize > 2 * MB) {
          $msgError = "size";
        }
        if (empty($msgError)) {
          move_uploaded_file($imagetmp,  "$imagePath/" . $imagename);
          return $imagename;
        } else {
          return "failure";
        }
    } else {
       return null;
    }
    
  
}



function deleteFile($dir, $imagename)
{
    if (file_exists($dir . "/" . $imagename)) {
        unlink($dir . "/" . $imagename);
    }
}

function checkAuthenticate()
{
    if (isset($_SERVER['PHP_AUTH_USER'])  && isset($_SERVER['PHP_AUTH_PW'])) {
        if ($_SERVER['PHP_AUTH_USER'] != "wael" ||  $_SERVER['PHP_AUTH_PW'] != "wael12345") {
            header('WWW-Authenticate: Basic realm="My Realm"');
            header('HTTP/1.0 401 Unauthorized');
            echo 'Page Not Found';
            exit;
        }
    } else {
        exit;
    }

}

function result($count){
    if ($count > 0) {
        echo json_encode(array("status" => "success"));
    } else {
        echo json_encode(array("status" => "failure"));
    }
}


function insertCart($table,$userId,$productId,$cartCount,$json = false){
    global $con;
    //check is it insert ?
    $stmt = $con->prepare("SELECT  * FROM $table WHERE `user_id` = ? AND `product_id` = ? AND order_id = ?");
    $stmt->execute(array($userId,$productId,0));
    $count  = $stmt->rowCount();
    if($count > 0){
        return 0;
        // echo json_encode(array("status" => "failure"));
    }else{
        $data = array(
            "user_id"=>$userId,
            "product_id"=>$productId,
            "count" => $cartCount
        );
        return insertData($table, $data,$json);
    }
}


function checkProductNo($userId){
    global $con;
    $table = "check_product_view";
    $userId = filterRequest("userId");
    $stmt = $con->prepare("SELECT * FROM $table WHERE `user_id` = ?");
    $stmt->execute([$userId]);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $product_ids = [];
    if (!empty($data)) {
        foreach ($data as $row) {
           if ($row['product_count']< $row['count']) {
            $product_ids[] = $row['product_id'];
           }     
        }
        if (empty($product_ids)){
            return null;
        } else {
            return $product_ids;
        }
    }else{
        return null;
    }
}

