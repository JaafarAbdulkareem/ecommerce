<?php
    include "../../connect.php";
    include '../notification/send_message.php';

    $table = "products";
    $id = filterRequest("id");
    $image = filterRequest("image");
    
    deleteFile("../../upload/product", $image);
//update for users application 
    sendFCMMessage(
        "users",
        "",
        "",
        null,
        "/home",
    );
    deleteData($table, "`id` = $id");
?>