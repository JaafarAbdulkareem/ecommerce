<?php
    include "../../connect.php";
    $table = "product_view";
    getAllData($table,"1=1");

?>