<?php
    include "../../connect.php";
    include '../notification/send_message.php';

    $table = "products";
    $id = filterRequest("id");
    $arabicName = filterRequest("arabicName");
    $englishName = filterRequest("englishName");
    $arabicDescription = filterRequest("arabicDescription");
    $englishDescription = filterRequest("englishDescription");
    $image = filterRequest("image");
    $count = filterRequest("count");
    $active = filterRequest("active");
    $price = filterRequest("price");
    $discount = filterRequest("discount");
    $categoryId = filterRequest("categoryId");
    
    if ($image == null || empty($image) || $image == "") {
        $data = array(
            "arabic_name" => $arabicName,
            "english_name" => $englishName,
            "arabic_description" => $arabicDescription,
            "english_description" => $englishDescription,
            "count" => $count,
            "active" => $active,
            "price" => $price,
            "discount" => $discount,
            "category_id" => $categoryId
        );
        
    } else {
        $newImage = imageUpload("../../upload/product","newImage");
        deleteFile("../../upload/product", $image);
        
        $data = array(
            "arabic_name" => $arabicName,
            "english_name" => $englishName,
            "arabic_description" => $arabicDescription,
            "english_description" => $englishDescription,
            "image" => $newImage,
            "count" => $count,
            "active" => $active,
            "price" => $price,
            "discount" => $discount,
            "category_id" => $categoryId
        );
        
    }
    
    $where = "`id` = $id";

    // updateData($table, $data, $where);
    $count = updateData($table, $data, $where,false);
    if ($count > 0) {
        sendFCMMessage(
            "users",
            "",
            "",
            null,
            "/home",
        );
        echo json_encode(array("status" => "success"));
    } else {
        echo json_encode(array("status" => "failure"));
    }
    
    // include "../../connect.php";
    // $table = "categories";
    // $id = filterRequest("id");
    // $arabicName = filterRequest("arabicName");
    // $englishName = filterRequest("englishName");
    // $image = filterRequest("image");
    // $newImage = imageUpload("../../upload/category","newImage");
    // if ($newImage == null || empty($newImage) || $newImage == "failure") {
    //     $data = array(
    //         "arabic_name" => $arabicName,
    //         "english_name" => $englishName,
    //     );
    // } else {

    //     deleteFile("../../upload/category", $image);
        
    //     $data = array(
    //         "arabic_name" => $arabicName,
    //         "english_name" => $englishName,
    //         "image" => $newImage,
    //     );
    // }
    
    // $where = "`id` = $id";

    // updateData($table, $data, $where);
    
?>
    
