<?php
    include "../../connect.php";
    include '../notification/send_message.php';

    $table = "products";

    $arabicName = filterRequest("arabicName");
    $englishName = filterRequest("englishName");
    $arabicDescription = filterRequest("arabicDescription");
    $englishDescription = filterRequest("englishDescription");
    $count = filterRequest("count");
    $active = filterRequest("active");
    $price = filterRequest("price");
    $discount = filterRequest("discount");
    $categoryId = filterRequest("categoryId");


    $image = imageUpload("../../upload/product","newImage");

    if(!isset($image) || $image == "failure"){
        echo json_encode(array("status" => "failure"));
    }else{
        $data = array(
            "arabic_name" => $arabicName,
            "english_name" => $englishName,
            "arabic_description" => $arabicDescription,
            "english_description" => $englishDescription,
            "image" => $image,
            "count" => $count,
            "active" => $active,
            "price" => $price,
            "discount" => $discount,
            "category_id" => $categoryId
        );
//update for users application 
        sendFCMMessage(
            "users",
            "",
            "",
            null,
            "/home",
        );
        $count = insertData($table, $data);
        
    }
    
?>