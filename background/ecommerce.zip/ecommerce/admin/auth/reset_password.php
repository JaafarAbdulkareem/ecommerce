<?php
    include "../../connect.php";
    $table = "admins";
    $email = filterRequest("email");
    $password = filterRequest("password");
    $stmt = $con->prepare("SELECT  * FROM $table WHERE  `email` = ? ");
    $stmt->execute(array($email));
    // $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $count  = $stmt->rowCount();
    // $data = array("password" => $password);
    // updateData($table, $data, "email = $email");

    if ($count > 0) {
        $stmt = $con->prepare("UPDATE $table SET `password` = $password WHERE `email` = ? ");
        $stmt->execute(array($email));
        $count = $count  = $stmt->rowCount();
        result($count);
    } else {
        echo json_encode(array("status" => "failure","data" => "noFound"));
    }  
?>