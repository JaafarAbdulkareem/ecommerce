<?php
    include "../../connect.php";
    $table = "admins";
    $email = filterRequest("email");
    $stmt = $con->prepare("SELECT  * FROM $table WHERE  `email` = ? ");
    $stmt->execute(array($email));
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $count  = $stmt->rowCount();
    if ($count > 0) {
        $verifyCode = rand(1000,9999);
        $stmt = $con->prepare("UPDATE $table SET `verify_code` = ? WHERE `email` = ? ");
        $stmt->execute(array($verifyCode,$email));
        echo json_encode(array("status" => "success", "data" => $verifyCode));
    } else {
        echo json_encode(array("status" => "failure"));
    }
    
    
    
?>