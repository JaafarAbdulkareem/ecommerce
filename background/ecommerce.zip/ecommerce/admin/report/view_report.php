<?php
    include "../../connect.php";

    $data = [];

    $data["dashboard_counts"] = returnData("dashboard_counts_view","1=1");
    $data["monthly_orders"] = returnAllData("monthly_orders_view");
    $data["orders_per_city"] = returnAllData("orders_per_city_view");
    $data["product_category_pie"] = returnAllData("product_category_pie_view");

    // Check if any of the required data is null
    if (
        $data["dashboard_counts"] === null ||
        $data["monthly_orders"] === null ||
        $data["orders_per_city"] === null ||
        $data["product_category_pie"] === null
    ) {
        echo json_encode(array("status" => "failure"));
    } else {
        echo json_encode(array("status" => "success", "data" => $data));
    }
?>
