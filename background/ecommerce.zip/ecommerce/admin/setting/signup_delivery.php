<?php
    include "../../connect.php";
    include '../notification/send_message.php';

    $table = "delivery_men";

    $username = filterRequest("username");
    $age = filterRequest("age");
    $email    = filterRequest("email");
    $password = filterRequest("password"); // NOTE: hash before saving
    $phone    = filterRequest("phone");
    $verifyCode = rand(1000, 9999);

    // Check if user already exists
    $stmt = $con->prepare("SELECT * FROM $table WHERE email = ? OR phone = ?");
    $stmt->execute([$email, $phone]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    $count = $stmt->rowCount();

    if ($count > 0) {
        if ($data['approve'] == 0) {
            // Update verify code
            $updateStmt = $con->prepare("UPDATE $table SET verify_code = ? WHERE email = ? AND password = ?");
            $updateStmt->execute([$verifyCode, $email, $password]); // Make sure to hash password
            if ($updateStmt->rowCount() > 0) {
                $deliveryTitle = "OTP";
                $deliveryMessage = "Your OTP is: {$verifyCode}";
                sendFCMMessage(
                    "delivery_men".$data['id'],
                    $deliveryTitle,
                    $deliveryMessage,
                    null,
                    "/waitingOrder"
                );
                echo json_encode([
                    "status" => "failure",
                    "data" => "noApprove",
                    "verifyCode" => $verifyCode
                ]);
            } else {
                echo json_encode(["status" => "failure"]);
            }
        } else {
            echo json_encode(["status" => "failure", "data" => "found"]);
        }
    } else {
        // Hash password before storing
        // $hashedPassword = password_hash($password, PASSWORD_DEFAULT); // Optional if needed

        $insertData = [
            "username" => $username,
            "age" => $age,
            "email" => $email,
            "password" => $password, // Or $hashedPassword
            "phone" => $phone,
            "verify_code" => $verifyCode
        ];
        $count = insertData($table, $insertData, false);
        if ($count > 0) {
            $userId = $con->lastInsertId();
            $deliveryTitle = "OTP";
            $deliveryMessage = "Your OTP is: {$verifyCode}";
            sendFCMMessage(
                "delivery_men$userId",
                $deliveryTitle,
                $deliveryMessage,
                null,
                null,
            );
            echo json_encode([
                "status" => "success",
                "data" => $userId
                // "data" => $verifyCode
            ]);
        } else {
            echo json_encode(["status" => "failure"]);
        }
    }
?>
