<?php
    include "../../connect.php";
    $table = "delivery_men";
    getAllData($table,"1=1 ORDER BY `id` DESC");

?>