<?php
    include "../../connect.php";
    $table = "delivery_men";
    $id = filterRequest("id");
    deleteData($table, "`id` = $id");
?>