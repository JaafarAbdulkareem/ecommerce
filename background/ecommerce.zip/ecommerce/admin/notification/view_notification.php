<?php
    include "../../connect.php";
    $table = "admins_notification";
    $userId = filterRequest("userId");
    // $userId = 1;
    $recipient = 0;

    getAllData($table, "`user_id` = ? AND `recipient` = ? ORDER BY `id` DESC", [$userId,$recipient]);
    // $stmt = $con->prepare("SELECT  * FROM $table WHERE `user_id` = ? AND `recipient` = ? ");
    // $stmt->execute(array($userId,$recipient));
    // $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    // $count  = $stmt->rowCount();
    // if ($count > 0) {
    //     echo json_encode(array("status" => "success", "data" => $data));
    // } else {
    //     echo json_encode(array("status" => "failure"));
    // }

?>