<?php
    include "../../connect.php";
    $table = "admins_notification";
    $id = filterRequest("id");
    $recipient = 2;
    deleteData($table, "`id` = $id AND `recipient` = $recipient");
?>