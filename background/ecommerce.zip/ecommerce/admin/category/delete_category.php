<?php
    include "../../connect.php";
    $table = "categories";
    $id = filterRequest("id");
    $image = filterRequest("image");
    
    deleteFile("../../upload/category", $image);

    deleteData($table, "`id` = $id");
?>