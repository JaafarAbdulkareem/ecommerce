<?php
    include "../../connect.php";
    $table = "categories";
    $id = filterRequest("id");
    $arabicName = filterRequest("arabicName");
    $englishName = filterRequest("englishName");
    $image = filterRequest("image");
    
    if ($image == null || empty($image) || $image == "") {
        $data = array(
            "arabic_name" => $arabicName,
            "english_name" => $englishName,
        );
    } else {
        $newImage = imageUpload("../../upload/category","newImage");
        deleteFile("../../upload/category", $image);
        
        $data = array(
            "arabic_name" => $arabicName,
            "english_name" => $englishName,
            "image" => $newImage,
        );
    }
    
    $where = "`id` = $id";

    updateData($table, $data, $where);
    
    // include "../../connect.php";
    // $table = "categories";
    // $id = filterRequest("id");
    // $arabicName = filterRequest("arabicName");
    // $englishName = filterRequest("englishName");
    // $image = filterRequest("image");
    // $newImage = imageUpload("../../upload/category","newImage");
    // if ($newImage == null || empty($newImage) || $newImage == "failure") {
    //     $data = array(
    //         "arabic_name" => $arabicName,
    //         "english_name" => $englishName,
    //     );
    // } else {

    //     deleteFile("../../upload/category", $image);
        
    //     $data = array(
    //         "arabic_name" => $arabicName,
    //         "english_name" => $englishName,
    //         "image" => $newImage,
    //     );
    // }
    
    // $where = "`id` = $id";

    // updateData($table, $data, $where);
    
?>
    
