<?php
    include "../../connect.php";
    $table = "categories";
    getAllData($table,"1=1");

?>