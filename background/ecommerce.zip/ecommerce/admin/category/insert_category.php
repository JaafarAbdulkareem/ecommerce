<?php
    include "../../connect.php";
    $table = "categories";
    $arabicName = filterRequest("arabicName");
    $englishName = filterRequest("englishName");

    $image = imageUpload("../../upload/category","newImage");

    if(!isset($image) || $image == "failure"){
        echo json_encode(array("status" => "failure"));
    }else{
        $data = array(
            "arabic_name" => $arabicName,
            "english_name" => $englishName,
            "image" => $image,
        );
    
        $count = insertData($table, $data);
    }
    
?>