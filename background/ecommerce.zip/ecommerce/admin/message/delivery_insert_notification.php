<?php
    include_once __DIR__ . '/../../connect.php';
    include __DIR__ . '/../notification/send_message.php';
    $table = "delivery_men_notification";
    
    $title = filterRequest("title");
    $body  = filterRequest("body");
    $userId = filterRequest("userId");
    $adminId = 1;
    $recipient = 2;

    if ($userId === null || $userId === "") {
        // Case: userId not provided – insert for all users
        $stmt = $con->prepare("SELECT id FROM delivery_men");
        $stmt->execute();
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
        $insertedCount = 0;
    
        foreach ($users as $user) {
            $data = array(
                "title"   => $title,
                "body"    => $body,
                "user_id" => $user['id'],
            );
            $insertedCount += insertData($table, $data,false); // assuming insertData returns 1 on success
            sendFCMMessage("delivery_men".$user['id'], $title, $body, null, null);
        }
    
        $data = array(
            "title"   => $title,
            "body"    => $body,
            "recipient" => $recipient,
            "user_id" => $adminId,
        );
        insertData("admins_notification", $data,false);

        echo json_encode([
            "status" => $insertedCount > 0 ? "success" : "failure"
        ]);
    } else {
        // Case: userId provided – insert for specific user
        $data = array(
            "title"   => $title,
            "body"    => $body,
            "user_id" => $userId,
        );
    
        $count = insertData($table, $data);
        sendFCMMessage("delivery_men".$userId, $title, $body, null, null);
    
        $data = array(
            "title"   => $title,
            "body"    => $body,
            "recipient" => $recipient,
            "user_id" => $adminId,
        );
        insertData("admins_notification", $data,false);
        
        echo json_encode([
            "status" => $count > 0 ? "success" : "failure"
        ]);
    }
?>