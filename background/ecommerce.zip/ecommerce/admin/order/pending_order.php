<?php
//     include "../../connect.php";
//     include '../notification/send_message.php';
//     $table = "orders";
//     $id = filterRequest("id");
//     $status = 1;
//     $userId = filterRequest("userId");

//     $data = array(
//         // "type_address"=>$typeAddress,
//         "status"=> $status,
        
//         // "user_id"=>$userId,
//     );

// //user notification
//     $title = "Order Confirmed"; 
//     $userMessage = "✅ Good news! Your order has been confirmed and is being prepared."; 
    
    
    
//     $where = "`id` = $id AND `user_id` = $userId AND `status` = 0 AND `type_delivery` = 0"; //type_delivery = 0 delivery
//     $count = updateData($table, $data, $where,false);

//     if ($count > 0) {    
//         sendFCMMessage(
//             "users$userId",
//             $title,
//             $userMessage,
//             null,
//             "/order",
//           );
//         echo json_encode(array("status" => "success"));
//     } else {
//         echo json_encode(array("status" => "failure"));
//     }
?>