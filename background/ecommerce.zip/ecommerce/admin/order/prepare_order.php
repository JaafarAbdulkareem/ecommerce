<?php
    include "../../connect.php";
    include '../notification/send_message.php';
    $table = "orders";
    $id = filterRequest("id");
    $status = 1;
    $userId = filterRequest("userId");

    $data = array(
        // "type_address"=>$typeAddress,
        "status"=> $status,
        
        // "user_id"=>$userId,
    );

    $where = "`id` = $id AND `user_id` = $userId AND `status` = 0 AND `type_delivery` = 0";
    $count = updateData($table, $data, $where,false);

    if ($count > 0) {
        // creat view for accepted section in delivery application and send with send message after update
    //delivery notification
        $deliveryTitle = "New Delivery Assigned"; 
        $deliveryMessage = "📦 You have a new delivery to make. Please check your delivery list for details.";    
        sendFCMMessage(
            "delivery_men",
            $deliveryTitle,
            $deliveryMessage,
            null,
            "/waitingOrder",
        );
    //user notification
        $title = "Order Confirmed"; 
        $userMessage = "✅ Good news! Your order has been confirmed and is being prepared.";
        sendFCMMessage(
            "users$userId",
            $title,
            $userMessage,
            null,
            "/order",          
        ); 
        $data = returnData("delivery_prepare_order_view", "id = ?", [$id]);
        echo json_encode(array("status" => "success", "data" => $data));
    } else {
        echo json_encode(array("status" => "failure"));
    }
?>