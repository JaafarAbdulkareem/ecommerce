<?php
    include "../../connect.php";
    include '../notification/send_message.php';
    $table = "orders";
    $id = filterRequest("id");
    $status = 4;
    $userId = filterRequest("userId");
    
    $data = array(
        // "type_address"=>$typeAddress,
        "status"=> $status,
        
        // "user_id"=>$userId,
    );



    $where = "`id` = $id AND `user_id` = $userId AND `status` = 3 AND `type_delivery` = 0";
    $count = updateData($table, $data, $where,false);

    if ($count > 0) {   
//user notification
        $userTitle = "Order Delivered"; 
        $userMessage = "📦 Your order has been delivered. Enjoy!"; 
        $dataUserNotification = array(
            "title"   => $userTitle,
            "body"    => $userMessage,
            "user_id" => $userId,
        );
        sendFCMMessage(
            "users$userId",
            $userTitle,
            $userMessage,
            null,
            "/order",
          );
        insertData("users_notification", $dataUserNotification,false);
        
//admin notification
        // $adminTitle = "Order Delivered";
        // $adminMessage =  "✅ Order #$id has been successfully delivered to user #$userId."; 
        // $dataAdminNotification = array(
        //     "title"   => $adminTitle,
        //     "body"    => $adminMessage,
        //     "user_id" => $adminId,
        // ); 
        // sendFCMMessage(
        //     "admins",
        //     $adminTitle,
        //     $adminMessage,
        //     null,
        //     null,
        // );  
        // insertData("admins_notification", $dataAdminNotification,false);

        echo json_encode(array("status" => "success"));
    } else {
        echo json_encode(array("status" => "failure"));
    }
?>