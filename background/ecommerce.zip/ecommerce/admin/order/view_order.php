<?php
    include "../../connect.php";
    $table = "order_user_view";
    getAllData($table,"1 = 1");

?>