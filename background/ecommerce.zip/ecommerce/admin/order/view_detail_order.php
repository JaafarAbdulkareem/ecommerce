<?php
    include "../../connect.php";

    $table = "detail_order_view";
    $id = filterRequest("id");//order id 
    $userId = filterRequest("userId");

    // Get the order
    $stmt = $con->prepare("SELECT * FROM $table WHERE `id` = ? AND `user_id` = ?");
    $stmt->execute([$id, $userId]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($data) {
        // Decode product JSON data
        $data['products_data'] = json_decode($data['products_data'], true);

        // Add address data if available
        if (!empty($data['address_id'])) {
            $addressId = $data['address_id'];
            $data['address'] = returnData("order_address", "`id` = ?", [$addressId]);
        }

        // Return the formatted response
        echo json_encode([
            "status" => "success",
            "data" => $data
        ]);
    } else {
        echo json_encode([
            "status" => "failure"
        ]);
    }
?>


