<?php
     include "../../connect.php";
     include '../notification/send_message.php';
 
     $table = "orders";
     $id = filterRequest("id");
     $status = 3;
     $userId = filterRequest("userId");
     $adminId = "1";
 
     $data = array(
         "status" => $status,
     );
 
    $where = "`id` = $id AND `user_id` = $userId AND `status` = 2 AND `type_delivery` = 0";
    $count = updateData($table, $data, $where, false);
 
     if ($count > 0) {
    //user notification
        $userTitle = "Order On The Way"; 
        $userMessage = "🚚 Your order is on the way! Sit tight, it's arriving soon."; 

         sendFCMMessage(
             "users$userId",
             $userTitle,
             $userMessage,
             null,
             "/order",
         );
         
         echo json_encode(array("status" => "success"));
     } else {
         echo json_encode(array("status" => "failure"));
     }
?>