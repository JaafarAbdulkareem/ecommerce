<?php
    include "../../connect.php";
    include '../notification/send_message.php';
    $table = "orders";
    $id = filterRequest("id");
    $status = 4;
    $userId = filterRequest("userId");

    $data = array(
        // "type_address"=>$typeAddress,
        "status"=> $status,
        
        // "user_id"=>$userId,
    );


    //user notification
    $userTitle = "Order Confirmed"; 
    $userMessage = "✅ Good news! Your order has been confirmed and is being prepared."; 
    $dataUserNotification = array(
        "title"   => $userTitle,
        "body"    => $userMessage,
        "user_id" => $userId,
    );
    

    $where = "`id` = $id AND `user_id` = $userId AND `status` = 0";
    $count = updateData($table, $data, $where,false);

    if ($count > 0) {    
        sendFCMMessage(
            "users$userId",
            $userTitle,
            $userMessage,
            null,
            "/order",
          );
        insertData("users_notification", $dataUserNotification,false);
        
        echo json_encode(array("status" => "success"));
    } else {
        echo json_encode(array("status" => "failure"));
    }
?>