<?php
    include "../../connect.php";
    $table = "product_view";
    $searchName = filterRequest("searchName");

    $stmt = $con->prepare("SELECT * FROM $table WHERE `active` = ? AND `countProduct` != ? AND (`english_name` LIKE '%$searchName%' OR `arabic_name` LIKE '%$searchName%')");
    $stmt->execute([1,0]);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $count  = $stmt->rowCount();
    if ($count > 0) {
        echo json_encode(array("status" => "success","data" => $data));
    } else {
        echo json_encode(array("status" => "failure"));
    }
    
 ?>