<?php
    include "../../connect.php";
  
    $data["category"] =  returnAllData("categories");
    $data["product"] =  returnAllData("product_view");

    // echo json_encode(array("status" => "success", "data" => $data));
    if ($data["category"] == null) {
        echo json_encode(array("status" => "failure"));
    } else {
        // // $data["product"] =  returnAllData("product_view");
        // if ($data["product"] == null) {
        //     echo json_encode(array("status" => "failure"));
        // } else {
            echo json_encode(array("status" => "success", "data" => $data));
        // }  
    }
    
    
?>