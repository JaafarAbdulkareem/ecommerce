<?php
    include "../../connect.php";
    $table = "categories";
   $category =  returnAllData($table);
    print_r($category);
    // $stmt = $con->prepare("SELECT  * FROM $table  ");
    // $stmt->execute();
    // $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    // $count  = $stmt->rowCount();
    // if ($count > 0){
    //     echo json_encode(array("status" => "success", "data" => $data));
    // } else {
    //     echo json_encode(array("status" => "failure"));
    // }
    // return $data;
?>