<?php
    include "../../connect.php";
    $table = "users";
    $userId = filterRequest("userId");
    
    $stmt = $con->prepare("SELECT * FROM $table WHERE id = ?");
    $stmt->execute([$userId]);
    $dataFetch = $stmt->fetch(PDO::FETCH_ASSOC);
    $count = $stmt->rowCount();
    
    if ($count > 0) {
        $stmt = $con->prepare("SELECT  * FROM `address`  WHERE user_id = ? ");
        $stmt->execute([$userId]);
        $address = $stmt->fetchAll(PDO::FETCH_ASSOC);
        // $address = count($address) > 0 ? $address : null;
        $data = [
            "id"       => $dataFetch["id"],
            "username" => $dataFetch["username"],
            "email"    => $dataFetch["email"],
            "phone"    => $dataFetch["phone"],
            "password" => $dataFetch["password"],
            "time_create" => $dataFetch["time_create"],
            "address" => $address
        ];
        echo json_encode([
            "status" => "success",
            "data" => $data
        ]);
    } else {
        echo json_encode(["status" => "failure"]);
    }
    
    
    
?>