<?php
    include "../../connect.php";
    // include "../../functions.php";
    include "stripe_helpers.php"; // ✅ include the reusable Stripe function
    
    $table = "users";
    $username = filterRequest("username");
    $email = filterRequest("email");
    $password = filterRequest("password");
    $phone = filterRequest("phone");
    $verifyCode = rand(1000, 9999);
    $secretKey = filterRequest("secret_key");
    
    // Check if email or phone exists
    $stmt = $con->prepare("SELECT * FROM $table WHERE `email` = ? OR `phone` = ?");
    $stmt->execute([$email, $phone]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode(["status" => "failure", "message" => "Email or phone already exists"]);
        exit;
    }
    
    // ✅ Call the function to create Stripe customer
    $stripeResult = createStripeCustomer($username, $email, $phone, $secretKey);
    
    if ($stripeResult["status"] !== "success") {
        echo json_encode([
            "status" => "failure",
            "message" => "Failed to create Stripe customer",
            "error" => $stripeResult
        ]);
        exit;
    }
    
    $customerId = $stripeResult["customer_id"];
    
    
    // Insert new user into database
    $data = [
        "username"     => $username,
        "email"        => $email,
        "password"     => $password,
        "phone"        => $phone,
        "verify_code"  => $verifyCode,
        "customer_id"  => $customerId
    ];
    
    $count = insertData($table, $data, false);
    
    if ($count > 0) {
        echo json_encode([
            "status" => "success",
            "data" => $verifyCode,
            "customer_id" => $customerId
        ]);
    } else {
        echo json_encode(["status" => "failure", "message" => "Database insert failed"]);
    }
    
    // include "../../connect.php";
    // $table = "users";
    // $username = filterRequest("username");
    // $email = filterRequest("email");
    // $password = filterRequest("password");
    // $phone = filterRequest("phone");
    // $verifyCode = rand(1000,9999);
    
    // $stmt = $con->prepare("SELECT  * FROM $table WHERE  `email` = ? OR `phone` = ? ");
    // $stmt->execute(array($email,$phone));
    // $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    // $count  = $stmt->rowCount();
    // if ($count > 0) {
    //     echo json_encode(array("status" => "failure"));
    // } else {
    //     $data = array(
    //         "username"=>$username,
    //         "email"=>$email,
    //         "password"=>$password,
    //         "phone"=>$phone,
    //         "verify_code"=>$verifyCode,
    //     );
    //     $count = insertData($table, $data, false);
    //     if ($count > 0) {
    //         echo json_encode(array("status" => "success", "data" => $verifyCode));
    //     } else {
    //         echo json_encode(array("status" => "failure"));
    //     }
    // }
    
?>