<?php
    include "../../connect.php";
    $table = 'users';

    // send OTP by phone number

    $email = filterRequest("email");
    $password = filterRequest("password");
    $verifyCode = filterRequest("verifyCode");
    
    $stmt = $con->prepare("SELECT  * FROM $table WHERE `email` = ? AND `password` = ? AND `verify_code` = ? ");
    $stmt->execute(array($email,$password,$verifyCode));
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $count  = $stmt->rowCount();
    if ($count > 0) {
        $stmt = $con->prepare("UPDATE $table SET `approve` = 1 WHERE `email` = ? AND `password` = ?");
        $stmt->execute(array($email,$password));
        $count = $count  = $stmt->rowCount();
        result($count);
    } else {
        echo json_encode(array("status" => "failure"));
    }
?>