<?php
function createStripeCustomer($name, $email, $phone, $secretKey) {
    $url = 'https://api.stripe.com/v1/customers';

    $body = http_build_query([
        'name'  => $name,
        'email' => $email,
        'phone' => $phone,
    ]);

    $headers = [
        "Authorization: Bearer $secretKey",
        "Content-Type: application/x-www-form-urlencoded",
    ];

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $body,
        CURLOPT_HTTPHEADER => $headers,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if (curl_errno($ch)) {
        return [
            "status" => "failure",
            "message" => "cURL error: " . curl_error($ch)
        ];
    }

    $data = json_decode($response, true);

    if ($httpCode >= 200 && $httpCode < 300 && isset($data['id'])) {
        return [
            "status" => "success",
            "customer_id" => $data['id']
        ];
    } else {
        return [
            "status" => "failure",
            "http_code" => $httpCode,
            "message" => $data
        ];
    }
}
