<?php
    include "../../connect.php";
    $table = 'users';

    $email = filterRequest("email");
    $verifyCode = filterRequest("verifyCode");
    
    $stmt = $con->prepare("SELECT  * FROM $table WHERE `email` = ? AND `verify_code` = ? ");
    $stmt->execute(array($email,$verifyCode));
    $count  = $stmt->rowCount();
    if ($count > 0) {
        $stmt = $con->prepare("UPDATE $table SET `approve` = 1 WHERE `email` = ? ");
        $stmt->execute(array($email));
        echo json_encode(array("status" => "success"));
        // $count = $count  = $stmt->rowCount();
        // result($count);
    } else {
        echo json_encode(array("status" => "failure"));
    }
?>