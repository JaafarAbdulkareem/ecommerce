<?php
    include "../../connect.php";
    $table = "users";
    $email = filterRequest("email");
    $password = filterRequest("password");
    $approve = 1;
    
    $stmt = $con->prepare("SELECT  * FROM $table WHERE  `email` = ? AND `password` = ? ");
    $stmt->execute(array($email,$password));
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    $count  = $stmt->rowCount();
    if ($count > 0) {
        $stmt = $con->prepare("SELECT  * FROM $table WHERE  `email` = ? AND `password` = ? AND `approve` = ?");
        $stmt->execute(array($email,$password,$approve));
        $count  = $stmt->rowCount();
        if($count){
            // $data = ret
            echo json_encode(array("status" => "success","data" => $data));
        }else{
            $verifyCode = rand(1000,9999);
            $stmt = $con->prepare("UPDATE $table SET `verify_code` = ? WHERE `email` = ? AND `password` = ?");
            $stmt->execute(array($verifyCode,$email,$password));
            echo json_encode(array("status" => "failure","data" => "noApprove","verifyCode" => $verifyCode ));
        }

    } else {
        echo json_encode(array("status" => "failure","data" => "noFound"));
    }
    
    
    
?>