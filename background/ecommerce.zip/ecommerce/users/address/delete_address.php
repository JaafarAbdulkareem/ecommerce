<?php
    include "../../connect.php";
    $table = "address";
    $id = filterRequest("id");
    deleteData($table, "`id` = $id");
?>