<?php
    include "../../connect.php";
    $table = "address";
    $id = filterRequest("id");
    $typeAddress = filterRequest("typeAddress");
    $city = filterRequest("city");
    $street = filterRequest("street");
    $detailAddress = filterRequest("detailAddress");
    $latitude = filterRequest("latitude");
    $longitude = filterRequest("longitude");
    $userId = filterRequest("userId");

    $data = array(
        "type_address"=>$typeAddress,
        "city"=>$city,
        "street"=>$street,
        "detail_address"=>$detailAddress,
        "latitude"=>$latitude,
        "longitude"=>$longitude,
        "user_id"=>$userId,
    );

    $where = "`id` = $id";

    updateData($table, $data, $where);
?>