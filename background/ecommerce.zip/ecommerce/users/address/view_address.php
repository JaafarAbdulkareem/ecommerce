<?php
    include "../../connect.php";
    $table = "address";
    $userId = filterRequest("userId");
    
    $stmt = $con->prepare("SELECT  * FROM $table WHERE `user_id` = ?  ");
    $stmt->execute(array($userId));
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $count  = $stmt->rowCount();
    if ($count > 0) {
        echo json_encode(array("status" => "success", "data" => $data));
    } else {
        echo json_encode(array("status" => "failure"));
    }

?>