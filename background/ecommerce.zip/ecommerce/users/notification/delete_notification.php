<?php
    include "../../connect.php";
    $table = "users_notification";
    $id = filterRequest("id");
    deleteData($table, "`id` = $id");
?>