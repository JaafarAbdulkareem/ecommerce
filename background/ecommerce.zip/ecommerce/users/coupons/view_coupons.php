<?php
    include "../../connect.php";
    $couponsName = filterRequest("couponsName");
    $userId = filterRequest("userId");
    $now = date("Y-m-d H:i:s");
    $where = "`coupons_name` = ? AND `count` > ? AND `expiry_date` > ?";
    $value = array($couponsName,0,$now);
    $data =  returnData('coupons', $where, $value);
    if (!empty($data)){
        $where = "`coupons_id` = ? AND `user_id` = ?";
        $value = array($data['id'],$userId);
        $data2 =  returnData('check_users_coupons', $where, $value);
        if (empty($data2)){
                echo json_encode(array("status" => "success", "data" => $data));
            } else {
                echo json_encode(array("status" => "failure"));
            }
    } else {
        echo json_encode(array("status" => "failure"));
    }
    // include "../connect.php";
    // $table = "coupons";
    // $couponsName = filterRequest("couponsName");
    // $now = date("Y-m-d H:i:s");
    // $where = "`coupons_name` = ? AND `count` > ? AND `expiry_date` > ?";
    // $value = array($couponsName,0,$now);
    // $data =  returnData($table, $where, $value);

    // if (!empty($data)){
    //     echo json_encode(array("status" => "success", "data" => $data));
    // } else {
    //     echo json_encode(array("status" => "failure"));
    // }
    
?>