<?php

    include '../connect.php';
    $table = 'address';
    $userId = filterRequest("userId");
    $addressId = filterRequest("addressId");

    $sql = "INSERT INTO order_address (type_address, city, street, detail_address, latitude, longitude, user_id)
        SELECT type_address, city, street, detail_address, latitude, longitude, user_id
        FROM $table
        WHERE id = ? AND user_id = ?";

    $stmt = $con->prepare($sql);
    // $stmt->execute(array(3,2));
    $stmt->execute(array($addressId,$userId));
    $count = $stmt->rowCount();
    if ($count > 0) {
        //remove
        echo json_encode(["status" => "success"]);
    }else{
        echo json_encode(["status" => "fali"]);
    }
    // $productId = filterRequest("productId");

    // $stmt = $con->prepare("SELECT * FROM `products` WHERE `id` = ? AND `count` >= ?");
    // $stmt->execute(array($productId,0));
    // $data = $stmt->fetch(PDO::FETCH_ASSOC);
    // $count  = $stmt->rowCount();
    // if($count>0){
    //     print_r( $data["count"]);
    //     print("if");
    //     if ($data['count'] == 0) {
    //         $data = array(
    //             "active"=> 0 ,
    //         );
    //         $where = "`id` = $productId";
    //         updateData('products', $data, $where,false);
    //     } else {
    //         $productCount = $data['count'] - 1;
    //         $data = array(
    //             "count"=> $productCount ,
    //         );
    //         $where = "`id` = $productId ";
    //         updateData('products', $data, $where,false);
    //     }
        
    // }else{
    //     //error
    // }
    
    
    
    // $stmt = $con->prepare("SELECT `product_id` FROM `cart` WHERE `user_id` = 2");
    // $stmt->execute();
    // $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // $product_ids = [];

    // if (!empty($data)) {
    //     foreach ($data as $row) {
    //         $product_ids[] = $row['product_id'];
    //     }
    // }

    // // Output the result
    // print_r($product_ids);
?>