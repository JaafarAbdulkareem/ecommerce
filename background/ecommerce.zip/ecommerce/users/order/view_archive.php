<?php
    include "../../connect.php";
    $table = "orders";
    $userId = filterRequest("userId");
    
    $stmt = $con->prepare("SELECT  * FROM $table WHERE `user_id` = ?  AND `status` > ?");
    $stmt->execute(array($userId,3)); //3 is delivery on way
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $count  = $stmt->rowCount();
    if ($count > 0) {
        echo json_encode(array("status" => "success", "data" => $data));
    } else {
        echo json_encode(array("status" => "failure"));
    }

?>