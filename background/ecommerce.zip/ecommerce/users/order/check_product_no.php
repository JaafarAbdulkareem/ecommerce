<?php
    include "../../connect.php";
    $table = "check_product_view";
    $userId = filterRequest("userId");
    $stmt = $con->prepare("SELECT * FROM $table WHERE `user_id` = ? AND `product_count`< `count`");
    $stmt->execute([$userId]);
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $count = $stmt->rowCount();
    // $data = checkProductNo($userId);
    // print_r($data);
    if (!$count > 0){
        echo json_encode(array("status" => "success"));
    } else {
        echo json_encode(array("status" => "failure", "data" => $data));
    }

    // $product_ids = [];
    // print_r($data);
    // if (!empty($data)) {
    //     print("not empty");
    //     foreach ($data as $row) {
    //        if ($row['product_count']< $row['count']) {
    //         $product_ids[] = $row['product_id'];
    //        }     
    //     }

    //     if (empty($product_ids)){
    //         echo json_encode(array("status" => "success"));
    //     } else {
    //         echo json_encode(array("status" => "failure", "data" => $product_ids));
    //     }
    // }else{
    //     print("empty");

    //     echo json_encode(array("status" => "success"));
    // }

    // // Output the result
    // print_r($product_ids);

    
    
?>