<?php

include "../../connect.php";
    // $listSubmitDataEncoded = filterRequest("listSubmitData"); // e.g., %5B%7B...
    // $listSubmitDataJson = urldecode($listSubmitDataEncoded);  // Convert to readable JSON
    // $listSubmitData = json_decode($listSubmitDataJson, true);

    // if (!is_array($listSubmitData)) {
    //     echo json_encode(["status" => "failure", "data" => "Invalid listSubmitData"]);
    //     exit;
    // }
    $listSubmitDataJson = isset($_POST["listSubmitData"]) ? $_POST["listSubmitData"] : null; // JSON string (already URL-decoded if sent from Flutter)
    $listSubmitData = json_decode($listSubmitDataJson, true);
    
    // 2. Validate listSubmitData
    if (!is_array($listSubmitData)) {
        echo json_encode([
            "status" => "failure",
            "data" => "Invalid listSubmitData",
            "debug" => $listSubmitDataJson
        ]);
        exit;
    }

// 1. Collect order request data
    // $listSubmitData         = filterRequest("listSubmitData");
    $userId                 = filterRequest("userId");
    $addressId              = filterRequest("addressId");
    $typePayment            = filterRequest("typePayment");
    $typeDelivery           = filterRequest("typeDelivery");
    $deliveryPrice          = filterRequest("deliveryPrice");
    $price                  = filterRequest("price");
    $totalPrice             = filterRequest("totalPrice");
    $couponsId              = filterRequest("couponsId");

//2. ListSubmitData is empty
    if (empty($listSubmitData)) {
        // Clean up cart with order_id = 0 (user's pending cart)
        $stmt = $con->prepare("DELETE FROM cart WHERE user_id = ? AND order_id = 0");
        $stmt->execute([$userId]);

        echo json_encode([
            "status" => "failure",
            "data" => "Empty listSubmitData - cart cleared"
        ]);
        exit;
    }
// 2. Insert order
    $orderData = [
        "type_payment"   => $typePayment,
        "type_delivery"  => $typeDelivery,
        "delivery_price" => $deliveryPrice,
        "price"          => $price,
        "total_price"    => $totalPrice,
        "user_id"        => $userId,
    ];

    insertData("orders", $orderData,false);
    $orderId = $con->lastInsertId();

// 3. Update cart with order_id
    $updateCartStmt = $con->prepare("UPDATE cart SET order_id = ? WHERE user_id = ? AND order_id = ?");
    $updateCartStmt->execute([$orderId, $userId,0]);

// 3. decrement count in product table
    foreach ($listSubmitData as $item) {
        $productId = $item['product_id'];
        $count = $item['count'];
        $stmt = $con->prepare("SELECT * FROM products WHERE id = ? AND count >= ?");
        $stmt->execute([$productId, $count]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);
        $newCount = $product['count'] - $count;
        $updateData = ["count" => $newCount];
        if ($newCount == 0) {
            $updateData["active"] = 0;
        }
        updateData("products", $updateData, "`id` = $productId", false);
    }

// 7. Insert into order_address if typeDelivery is 0
    if ($typeDelivery == 0) {

        $stmt = $con->prepare("
            INSERT INTO order_address (type_address, city, street, detail_address, latitude, longitude, user_id)
            SELECT type_address, city, street, detail_address, latitude, longitude, user_id
            FROM `address`
            WHERE id = ? AND user_id = ?
        ");
        $stmt->execute([$addressId, $userId]);

        if ($stmt->rowCount() > 0) {
            $addressInsertId = $con->lastInsertId();
            updateData('orders', ['address_id' =>  $addressInsertId], "`id` = $orderId", false);
        } else {
            deleteData('orders',"id = $orderId" ,false);
            echo json_encode(["status" => "failure", "data" => "insertAddressError"]);
            exit;
        }
    }
// 8. Apply coupon logic (optional)       
    $now = date("Y-m-d H:i:s");
    $stmt = $con->prepare("SELECT * FROM `coupons` WHERE `id` = ? AND `count` > ? AND `expiry_date` > ?");
    $stmt->execute([$couponsId, 0, $now]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($stmt->rowCount() > 0) {
        $newCount = $data['count'] - 1;
        updateData('coupons', ['count' => $newCount], "`id` = $couponsId", false);
        updateData('orders', ['coupons_id' => $data["id"]], "`id` = $orderId", false);
    }

// 9. Success response
    echo json_encode([
        "status" => "success",
        "data" => $orderId
    ]);
// Custom function to safely get raw POST data
// function getPostParam($key, $default = "") {
//     return $_POST[$key] ?? $default;
// }

// 1. Collect basic request data
// $userId        = filterRequest("userId");
// $addressId     = filterRequest("addressId");
// $typePayment   = filterRequest("typePayment");
// $typeDelivery  = filterRequest("typeDelivery");
// $deliveryPrice = filterRequest("deliveryPrice");
// $price         = filterRequest("price");
// $totalPrice    = filterRequest("totalPrice");
// $couponsId     = filterRequest("couponsId");

// 2. Decode the JSON list safely (use raw $_POST to avoid HTML escaping)
// $listSubmitDataRaw = getPostParam("listSubmitData");
// $listSubmitData = json_decode($listSubmitDataRaw, true);

// 3. Validate decoded JSON
// if (!is_array($listSubmitData)) {
//     echo json_encode([
//         "status" => "error",
//         "message" => "Invalid or missing 'listSubmitData'",
//         "json_error" => json_last_error_msg(),
//         "rawData" => $listSubmitDataRaw
//     ]);
//     exit;
// }

// 4. Insert order
// $orderData = [
//     "type_payment"   => $typePayment,
//     "type_delivery"  => $typeDelivery,
//     "delivery_price" => $deliveryPrice,
//     "price"          => $price,
//     "total_price"    => $totalPrice,
//     "user_id"        => $userId,
//     "address_id"     => $addressId,
//     "coupons_id"     => $couponsId
// ];

// insertData("orders", $orderData, false);
// $orderId = $con->lastInsertId();

// // 5. Update each cart item
// foreach ($listSubmitData as $item) {
//     if (!isset($item['product_id'], $item['count'])) {
//         continue; // skip incomplete entries
//     }

//     $productId = $item['product_id'];
//     $count     = $item['count'];

//     $updateCartStmt = $con->prepare("
//         UPDATE cart 
//         SET order_id = ?, count = ? 
//         WHERE user_id = ? AND order_id = 0 AND product_id = ?
//     ");
//     $updateCartStmt->execute([$orderId, $count, $userId, $productId]);
// }

// // 6. Optional: Clean up old cart entries
// deleteData('cart', "user_id = $userId AND order_id = 0");

// // 7. Return success
// echo json_encode(["status" => "success"]);

?>
