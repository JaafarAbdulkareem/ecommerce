<?php

    include "../../connect.php";

// 1. Collect order request data
    $userId        = filterRequest("userId");
    $addressId     = filterRequest("addressId");
    $typePayment   = filterRequest("typePayment");
    $typeDelivery  = filterRequest("typeDelivery");
    $deliveryPrice = filterRequest("deliveryPrice");
    $price         = filterRequest("price");
    $totalPrice    = filterRequest("totalPrice");
    $couponsId     = filterRequest("couponsId");

// 2. Insert order
    $orderData = [
        "type_payment"   => $typePayment,
        "type_delivery"  => $typeDelivery,
        "delivery_price" => $deliveryPrice,
        "price"          => $price,
        "total_price"    => $totalPrice,
        "user_id"        => $userId,
    ];

    insertData("orders", $orderData,false);
    $orderId = $con->lastInsertId();

// 3. Update cart with order_id
    $updateCartStmt = $con->prepare("UPDATE cart SET order_id = ? WHERE user_id = ? AND order_id = ?");
    $updateCartStmt->execute([$orderId, $userId,0]);

// 4. Get all cart items for this order
    $stmt = $con->prepare("SELECT * FROM cart WHERE order_id = ?");
    $stmt->execute([$orderId]);
    $cartItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

// 5. Validate and update product inventory
    $invalidProducts = [];

    foreach ($cartItems as $item) {
        $productId = $item['product_id'];
        $cartCount = $item['count'];

        $stmt = $con->prepare("SELECT * FROM products WHERE id = ? AND count >= ?");
        $stmt->execute([$productId, $cartCount]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($stmt->rowCount() == 0 || $product['active'] == 0) {
            $invalidProducts[] = $productId;
        }
    }
    
    

// 6. Handle invalid products
    if (!empty($invalidProducts)) {
        $updateCartStmt = $con->prepare("UPDATE cart SET order_id = ? WHERE user_id = ? AND order_id = ?");
        $updateCartStmt->execute([0, $userId,$orderId]);
        deleteData('orders',"id = $orderId" ,false);
        echo json_encode([
            "status" => "failure", "data" => $invalidProducts
        ]);
        exit;
    }

// 7. Insert into order_address if typeDelivery is 0
    if ($typeDelivery == 0) {

        $stmt = $con->prepare("
            INSERT INTO order_address (type_address, city, street, detail_address, latitude, longitude, user_id)
            SELECT type_address, city, street, detail_address, latitude, longitude, user_id
            FROM `address`
            WHERE id = ? AND user_id = ?
        ");
        $stmt->execute([$addressId, $userId]);

        if ($stmt->rowCount() > 0) {
            $addressInsertId = $con->lastInsertId();
            updateData('orders', ['address_id' =>  $addressInsertId], "`id` = $orderId", false);
        } else {
            deleteData('orders',"id = $orderId" ,false);
            echo json_encode(["status" => "failure", "data" => "insertAddressError"]);
            exit;
        }
    }
    
// 7. decrement count in product table 
    foreach ($cartItems as $item) {
        $productId = $item['product_id'];
        $cartCount = $item['count'];

        $newCount = $product['count'] - $cartCount;
        $updateData = ["count" => $newCount];

        if ($newCount == 0) {
            $updateData["active"] = 0;
        }

        updateData("products", $updateData, "`id` = $productId", false);
    }

// 8. Apply coupon logic (optional)       
    $now = date("Y-m-d H:i:s");
    $stmt = $con->prepare("SELECT * FROM `coupons` WHERE `id` = ? AND `count` > ? AND `expiry_date` > ?");
    $stmt->execute([$couponsId, 0, $now]);
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($stmt->rowCount() > 0) {
        $newCount = $data['count'] - 1;
        updateData('coupons', ['count' => $newCount], "`id` = $couponsId", false);
        updateData('orders', ['coupons_id' => $data["id"]], "`id` = $orderId", false);
        $data = array(
            "user_id" => $userId,
            "coupons_id" => $couponsId,
        );
    
        $count = insertData('check_users_coupons', $data,false);
    }

// 9. Success response
    echo json_encode([
        "status" => "success",
        "data" => $orderId
    ]);

 
?>