<?php
  include "../../connect.php";
  include "../notification/send_message.php";

  $id = filterRequest("id");

  // ✅ Step 1: Fetch cart items for this order
  $stmt = $con->prepare("SELECT product_id, count FROM cart WHERE order_id = ?");
  $stmt->execute([$id]);
  $cartItems = $stmt->fetchAll(PDO::FETCH_ASSOC);

  // ✅ Step 2: Increment product stock for each item
  foreach ($cartItems as $item) {
      $productId = $item['product_id'];
      $cartCount = $item['count'];

      $updateStmt = $con->prepare("UPDATE products SET count = count + ? WHERE id = ?");
      $updateStmt->execute([$cartCount, $productId]);
  }

  // ✅ Step 3: Delete order
  $table = "orders";
    $id = filterRequest("id");
    $where = "`id` = $id";
    deleteData($table, $where);

  // ✅ Step 4: Delete related cart items (optional, depends on your design)
  $deleteCart = $con->prepare("DELETE FROM cart WHERE order_id = ?");
  $deleteCart->execute([$id]);

  // ✅ Step 5: Notify admin
  sendFCMMessage(
      "admin",
      "Delete",
      "Custom Delete Order NO: $id",
      null,
      "/order"
  );

    // include "../../connect.php";
    // include "../notification/send_message.php";

    // $table = "orders";
    // $id = filterRequest("id");
    // $where = "`id` = $id";

    // deleteData($table, $where);
    // sendFCMMessage(
    //     "admin",
    //     "Delete",
    //     "Custom Delete Order NO: $id",
    //     null,
    //     "/order",
    //   );
?>