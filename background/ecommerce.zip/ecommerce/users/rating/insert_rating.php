<?php
    include "../../connect.php";

    $table = "ratings";
    $star = filterRequest("star");
    $comment = filterRequest("comment");
    $orderId = filterRequest("orderId");
    $productId = filterRequest("productId");
    $userId = filterRequest("userId");

    // Check if the user ID exists in the users table
    $userExists = returnData("orders", "`id` = ? AND `user_id` = ?", [$orderId,$userId]);

    if (empty($userExists)) {
        echo json_encode(array("status" => "failure", "data" => "userNotFound"));
        exit;
    }

    if (empty($comment)) {
        $comment = null;  // or just don't include the comment field in the insert, depending on your DB setup
    }
    // Check if this orderId already exists in the ratings table
    $existingRating = returnData($table, "`order_id` = ? AND `product_id` = ? AND `user_id` = ?", [$orderId,$productId,$userId]);
    // echo "is it : $existingRating";
    if ( !empty($existingRating) ) {
        // Order ID already has a rating, do not insert again
        echo json_encode(array("status" => "failure", "data" => "duplicate"));
        exit;
    }

    // If not exists, insert the new rating
    $data = array(
        "star" => $star,
        "comment" => $comment,
        "order_id" => $orderId,
        "product_id" => $productId,
        "user_id" => $userId,
    );

    $count = insertData($table, $data, false);

    if ($count) {
        // Check if product rating data exists (optional)
        $table_view = "product_ratings_view";
        $data_view = returnData($table_view, "`product_id` = ?", [$productId]);
        
        if ($data_view != null) {
            echo json_encode(array("status" => "success"));
        } else {
            echo json_encode(array("status" => "failure", "data" => "viewError"));
        }
    } else {
        echo json_encode(array("status" => "failure", "data" => "insertError"));
    }

    // include "../connect.php";
    // $table = "ratings";
    // $star = filterRequest("star");
    // $comment = filterRequest("comment");
    // $orderId = filterRequest("orderId");
    // $productId = filterRequest("productId");
    // $userId = filterRequest("userId");

    // $data = array(
    //     "star" => $star,
    //     "comment" => $comment,
    //     "order_id" => $orderId,
    //     "product_id" => $productId,
    //     "user_id" => $userId,
    // );
    // $count = insertData($table, $data,false) ;
    
    // $table = "product_ratings_view";
    // $data = returnData($table, "`product_id` = ?", [$productId]);
    // if ($data != null) {
    //     echo json_encode(array("status" => "success"));
    // } else {
    //     echo json_encode(array("status" => "failure"));
    // }
?>

