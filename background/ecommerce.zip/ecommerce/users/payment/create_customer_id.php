<?php
    // include "../../functions.php"; // This should contain filterRequest() and DB helpers

    // header("Content-Type: application/json");

    // // 1. Collect input
    // $name       = filterRequest("name");    
    // $email      = filterRequest("email");  
    // $phone      = filterRequest("phone");  
    // $secretKey  = filterRequest("secret_key");

    // // 2. Validate
    // if (!$name || !$email || !$phone || !$secretKey) {
    //     echo json_encode([
    //         "status" => "failure",
    //         "data" => "Missing one or more required fields: name, email, phone, secret_key"
    //     ]);
    //     exit;
    // }

    // // 3. Prepare Stripe request
    // $url = 'https://api.stripe.com/v1/customers';

    // $body = http_build_query([
    //     'name'  => $name,
    //     'email' => $email,
    //     'phone' => $phone,
    // ]);

    // $headers = [
    //     "Authorization: Bearer $secretKey",
    //     "Content-Type: application/x-www-form-urlencoded",
    // ];

    // // 4. Send cURL request
    // $ch = curl_init();
    // curl_setopt_array($ch, [
    //     CURLOPT_URL => $url,
    //     CURLOPT_RETURNTRANSFER => true,
    //     CURLOPT_POST => true,
    //     CURLOPT_POSTFIELDS => $body,
    //     CURLOPT_HTTPHEADER => $headers,
    // ]);

    // $response = curl_exec($ch);
    // $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    // // 5. Handle response
    // if (curl_errno($ch)) {
    //     echo json_encode([
    //         "status" => "failure",
    //         "data" => "cURL error: " . curl_error($ch)
    //     ]);
    // } else {
    //     $data = json_decode($response, true);

    //     if ($httpCode >= 200 && $httpCode < 300) {
    //         echo json_encode([
    //             "status" => "success",
    //             "data" => $data
    //         ]);
    //     } else {
    //         echo json_encode([
    //             "status" => "failure",
    //             "http_code" => $httpCode,
    //             "data" => $data
    //         ]);
    //     }
    // }

    // curl_close($ch);
?>
