<?php
    include "../../functions.php"; // This should contain filterRequest() and DB helpers

    header("Content-Type: application/json");
    
    // 1. Get inputs
    $amount     = filterRequest("amount");     // required
    $currency   = filterRequest("currency");   // required
    $customer   = filterRequest("customer");   // optional
    $secretKey  = filterRequest("secret_key"); // required
    
    // 2. Validate required parameters
    if (!$amount || !$currency || !$secretKey) {
        echo json_encode([
            "status" => "failure",
            "data" => "Missing required parameter(s): amount, currency, or secret_key"
        ]);
        exit;
    }
    
    // 3. Prepare Stripe request
    $url = 'https://api.stripe.com/v1/payment_intents';
    
    $params = [
        'amount' => $amount,                // in cents
        'currency' => $currency,
        'automatic_payment_methods[enabled]' => 'true'
    ];
    
    // Add customer ID if provided
    if ($customer) {
        $params['customer'] = $customer;
    }
    
    $body = http_build_query($params);
    
    $headers = [
        "Authorization: Bearer $secretKey",
        "Content-Type: application/x-www-form-urlencoded",
    ];
    
    // 4. Send cURL request
    $ch = curl_init();
    
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $body,
        CURLOPT_HTTPHEADER => $headers,
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    // 5. Handle result
    if (curl_errno($ch)) {
        echo json_encode([
            "status" => "failure",
            "data" => "cURL Error: " . curl_error($ch)
        ]);
    } else {
        $stripeData = json_decode($response, true);
    
        if ($httpCode >= 200 && $httpCode < 300) {
            echo json_encode([
                "status" => "success",
                "data" => $stripeData
            ]);
        } else {
            $errorMessage = $stripeData['error']['message'] ?? 'Unknown error from Stripe';
            echo json_encode([
                "status" => "failure",
                "http_code" => $httpCode,
                "data" => $errorMessage,
                "details" => $stripeData
            ]);
        }
    }
    
    curl_close($ch);
    // include "../../functions.php";

    // header("Content-Type: application/json");

    // // 1. Get inputs
    // $amount = filterRequest("amount");//isset($_REQUEST['amount']) ? $_REQUEST['amount'] : null;
    // $currency = filterRequest("currency");//isset($_REQUEST['currency']) ? $_REQUEST['currency'] : null;
    // $customer = filterRequest("customer");//isset($_REQUEST['currency']) ? $_REQUEST['currency'] : null;
    // $secretKey = filterRequest("secret_key");//isset($_REQUEST['secret_key']) ? $_REQUEST['secret_key'] : null; // new

    // // 2. Validate
    // if (!$amount || !$currency || !$secretKey) {
    //     echo json_encode([
    //         "status" => "failure",
    //         "message" => "Missing amount, currency, or secret_key"
    //     ]);
    //     exit;
    // }

    // // 3. Prepare Stripe request
    // $url = 'https://api.stripe.com/v1/payment_intents';

    // $body = http_build_query([
    //     'amount' => $amount, // Amount in cents
    //     'currency' => $currency,
    //     'customer' => $customer,
    //     'automatic_payment_methods[enabled]' => 'true',
    // ]);

    // $headers = [
    //     "Authorization: Bearer $secretKey",
    //     "Content-Type: application/x-www-form-urlencoded",
    // ];

    // // 4. Send cURL request
    // $ch = curl_init();
    // curl_setopt_array($ch, [
    //     CURLOPT_URL => $url,
    //     CURLOPT_RETURNTRANSFER => true,
    //     CURLOPT_POST => true,
    //     CURLOPT_POSTFIELDS => $body,
    //     CURLOPT_HTTPHEADER => $headers,
    // ]);

    // $response = curl_exec($ch);
    // $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    // // 5. Handle result
    // if (curl_errno($ch)) {
    //     echo json_encode([
    //         "status" => "failure",
    //         "message" => "cURL Error: " . curl_error($ch)
    //     ]);
    // } else {
    //     $stripeData = json_decode($response, true);

    //     if ($httpCode === 200) {
    //         echo json_encode([
    //             "status" => "success",
    //             "data" => $stripeData
    //         ]);
    //     } else {
    //         echo json_encode([
    //             "status" => "failure",
    //             "http_code" => $httpCode,
    //             "error" => $stripeData
    //         ]);
    //     }
    // }

    // curl_close($ch);
?>