<?php
    include "../../functions.php"; // This should contain filterRequest() and DB helpers

    header("Content-Type: application/json");

    // 1. Get inputs
    $customerId = filterRequest("customer");  
    $secretKey  = filterRequest("secret_key");  
    $stripeVersion = "2025-06-30.basil"; // required for ephemeral key creation

    // 2. Validate
    if (!$customerId || !$secretKey) {
        echo json_encode([
            "status" => "failure",
            "message" => "Missing customer or secret_key"
        ]);
        exit;
    }

    // 3. Prepare Stripe request
    $url = 'https://api.stripe.com/v1/ephemeral_keys';

    $body = http_build_query([
        'customer' => $customerId
    ]);

    $headers = [
        "Authorization: Bearer $secretKey",
        "Content-Type: application/x-www-form-urlencoded",
        "Stripe-Version: $stripeVersion"
    ];

    // 4. Send cURL request
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $body,
        CURLOPT_HTTPHEADER => $headers,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    // 5. Handle result
    if (curl_errno($ch)) {
        echo json_encode([
            "status" => "failure",
            "message" => "cURL Error: " . curl_error($ch)
        ]);
    } else {
        $data = json_decode($response, true);

        if ($httpCode >= 200 && $httpCode < 300) {
            echo json_encode([
                "status" => "success",
                "data" => $data
            ]);
        } else {
            echo json_encode([
                "status" => "failure",
                "http_code" => $httpCode,
                "data" => $data
            ]);
        }
    }

    curl_close($ch);
?>
