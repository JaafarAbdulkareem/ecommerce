<?php
    include "../../connect.php";
    $table = "cart";
    $userId = filterRequest("userId");
    $productId = filterRequest("productId");
    // $cartCount = 0;

    $stmt = $con->prepare("SELECT  * FROM $table WHERE `user_id` = ? AND `product_id` = ? AND `order_id` = ?");
    $stmt->execute(array($userId,$productId,0));
    $data = $stmt->fetch(PDO::FETCH_ASSOC);
    $count  = $stmt->rowCount();

    if ($count > 0) {
        $cartCount = $data["count"] ;
    //get count of product
        $stmt = $con->prepare("SELECT `count` FROM `products` WHERE  `id` = ? ");
        $stmt->execute(array($productId));
        $data = $stmt->fetch(PDO::FETCH_ASSOC);
    //compare bt count cart and count product
        if($cartCount < $data["count"]){
            // print("cart  $cartCount");
            $cartCount = $cartCount + 1;
            $stmt = $con->prepare("UPDATE $table SET `count` = $cartCount WHERE `user_id` = ? AND `product_id` = ? AND `order_id` = ?");
            $stmt->execute(array($userId,$productId,0));
            $count = $stmt->rowCount();
            if ($count > 0) {
                echo json_encode(array("status" => "success", "data" => $cartCount));
            } else {
                echo json_encode(array("status" => "failure"));
            }
        }else{
            echo json_encode(array("status" => "success", "data"=>"noChange")); 
        }
    // first time (when press button)
    } else {
        // print("cart2 :  ");
        // $data = array(
        //     "user_id"=>$userId,
        //     "product_id"=>$productId,
        // );
        $count = insertCart($table,$userId,$productId,1);
        // $count = insertData($table, $data,1 );
        if ($count > 0) {
            echo json_encode(array("status" => "success", "data" => 1));
        } else {
            echo json_encode(array("status" => "failure"));
        }
    }

?>