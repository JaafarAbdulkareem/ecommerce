<?php
    include "../../connect.php";
    $table = "cart";
    $userId = filterRequest("userId");
    
    $stmt = $con->prepare("SELECT  * FROM $table WHERE `user_id` = ? AND `order_id` = ?");
    $stmt->execute(array($userId,0));
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $count  = $stmt->rowCount();
    if ($count > 0) {
        echo json_encode(array("status" => "success", "data" => $data));
    } else {
        echo json_encode(array("status" => "failure"));
    }

?>