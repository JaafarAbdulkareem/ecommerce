<?php
    include "../../connect.php";
    $table = "cart";
    $userId = filterRequest("userId");
    $productId = filterRequest("productId");
    $cartCount = filterRequest("count");

    $count = insertCart($table,$userId,$productId,$cartCount);
  
    if ($count > 0) {
        echo json_encode(array("status" => "success", "data" => $cartCount));
    } else {
        // updata because it inserted before
        $stmt = $con->prepare("UPDATE $table SET `count` = $cartCount WHERE `user_id` = ? AND `product_id` = ? AND `order_id` = ?");
        $stmt->execute(array($userId,$productId,0));
        $count = $stmt->rowCount();
        if ($count > 0) {
            echo json_encode(array("status" => "success", "data" => $cartCount));
        } else {
            echo json_encode(array("status" => "failure"));
        }   
    }
    
    // $stmt = $con->prepare("SELECT  * FROM $table WHERE `user_id` = ? AND `product_id` = ? ");
    // $stmt->execute(array($userId,$productId));
    // $data = $stmt->fetch(PDO::FETCH_ASSOC);
    // $count  = $stmt->rowCount();
    // if ($count > ) {
    //     # code...
    // } else {
    //     # code...
    // }
    
    // if((empty($cartCount) and $cartCount == null) or $cartCount == 1){
    //     print("if");
    //     $count = insertCart($table,$userId,$productId);
    //     print("ifcount : $count");

    //     if ($count) {
    //         echo json_encode(array("status" => "success"));
    //     } else {
    //         echo json_encode(array("status" => "failure"));
    //     }
        
    // }else{
    //     print("else");
    //     $count = insertCart($table,$userId,$productId);
    //     if ($count > 0) {
            // $stmt = $con->prepare("UPDATE $table SET `count` = $cartCount WHERE `user_id` = ? AND `product_id` = ?");
            // $stmt->execute(array($userId,$productId));
            // $count = $stmt->rowCount();
            // if ($count > 0) {
            //     echo json_encode(array("status" => "success", "data" => $cartCount));
            // } else {
            //     echo json_encode(array("status" => "failure"));
            // }   
    //     } 
    //     else {
    //         echo json_encode(array("status" => "failure"));
    //     }
    // }
    
?>