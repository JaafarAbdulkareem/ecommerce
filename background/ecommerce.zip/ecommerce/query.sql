--add cart counter 
CREATE OR REPLACE VIEW product_view AS
SELECT 
    products.id,                         -- Keep product id as is
    products.arabic_name, 
    products.english_name, 
    products.arabic_description,
    products.english_description,
    products.image,                       -- Use alias for product image to avoid confusion
    products.count AS countProduct,
    IFNULL(cart.count, 0) AS count,       -- If cart count is NULL, return 0
    products.active, 
    products.price, 
    products.discount, 
    (products.price - (products.price * products.discount / 100)) AS discountPrice,
    products.time_create,

    -- Insert rating (default 5 if no ratings found)
    CASE 
        WHEN product_ratings_view.count IS NULL OR product_ratings_view.count = 0 THEN 5
        ELSE product_ratings_view.star / product_ratings_view.count
    END AS rating,

    categories.id AS category_id,         -- Alias for id to avoid conflict
    categories.arabic_name AS category_arabic_name, 
    categories.english_name AS category_english_name,
    categories.image AS category_image, 
    categories.time_create AS category_time_create

FROM products
INNER JOIN categories ON categories.id = products.category_id
LEFT JOIN cart ON cart.product_id = products.id AND cart.order_id = 0
LEFT JOIN product_ratings_view ON product_ratings_view.product_id = products.id;
 -- Use LEFT JOIN for cart table


-- CREATE OR REPLACE VIEW product_view AS
-- SELECT 
--     products.id,                         -- Keep product id as is
--     products.arabic_name, 
--     products.english_name, 
--     products.arabic_description,
--     products.english_description,
--     products.image ,     -- Use alias for product image to avoid confusion
--     products.count, 
--     products.active, 
--     products.price, 
--     products.discount, 
-- 	(products.price) - (products.price * products.discount/100) as discountPrice,
--     products.time_create,
    
--     categories.id AS category_id,        -- Alias for id to avoid conflict
--     categories.arabic_name AS category_arabic_name, 
--     categories.english_name AS category_english_name,
--     categories.image AS category_image, 
--     categories.time_create  AS category_time_create

   
-- FROM products
-- INNER JOIN categories 
-- ON categories.id = products.category_id;


--////check count product
CREATE OR REPLACE VIEW check_product_view AS
SELECT
    cart.*,  -- All columns from cart
    products.count AS product_count,
    products.active
FROM cart
INNER JOIN products ON products.id = cart.product_id;

--////coupons view

-- CREATE OR REPLACE VIEW coupons_view AS
-- SELECT
--     coupons.*,  -- All columns from cart
--     IFNULL(check_users_coupons.user_id, 0) AS user_id
-- FROM coupons
-- LEFT JOIN check_users_coupons ON coupons.id = check_users_coupons.coupons_id;


--/////invalid order view
CREATE OR REPLACE VIEW product_invalid_view AS
SELECT
    cart.product_id,
    products.count ,
    products.arabic_name,
    products.english_name,
	cart.user_id
FROM cart
INNER JOIN products ON products.id = cart.product_id
WHERE cart.order_id = 0 AND products.count < cart.count;

--/////detailOrder view
CREATE OR REPLACE VIEW detail_order_view AS
SELECT
    orders.id,
    orders.status,
    orders.price,
    orders.total_price,
    orders.address_id,
    orders.user_id,
    CONCAT(
        '[', 
        GROUP_CONCAT(
            CONCAT(
                '{',
                    '"product_id":', IFNULL(cart.product_id, 0), ',',
                    '"arabic_name":"', REPLACE(IFNULL(products.arabic_name, ''), '"', '\\"'), '",',
                    '"english_name":"', REPLACE(IFNULL(products.english_name, ''), '"', '\\"'), '",',
                    '"image":"', REPLACE(IFNULL(products.image, ''), '"', '\\"'), '",',
                    '"count":', IFNULL(cart.count, 0), ',',
                    '"price":', IFNULL(products.price, 0), ',',
                    '"total_price":', IFNULL(products.price - (products.price * products.discount / 100), 0), ',',
                    '"rating":', IF(ratings.id IS NOT NULL, 'true', 'false'),
                '}'
            )
            SEPARATOR ','
        ),
        ']'
    ) AS products_data
FROM orders
LEFT JOIN cart ON orders.id = cart.order_id
INNER JOIN products ON products.id = cart.product_id
LEFT JOIN ratings ON ratings.order_id = orders.id AND ratings.product_id = cart.product_id AND ratings.user_id = cart.user_id
GROUP BY orders.id;


-- CREATE OR REPLACE VIEW detail_order_view AS
-- SELECT
--     orders.id,
--     orders.status,
--     orders.price,
--     orders.total_price,
--     orders.address_id,
--     orders.user_id,
--     CONCAT(
--         '[', 
--         GROUP_CONCAT(
--             CONCAT(
--                 '{',
--                     '"product_id":', IFNULL(cart.product_id, 0), ',',
--                     '"arabic_name":"', REPLACE(IFNULL(products.arabic_name, ''), '"', '\\"'), '",',
--                     '"english_name":"', REPLACE(IFNULL(products.english_name, ''), '"', '\\"'), '",',
--                     '"count":', IFNULL(cart.count, 0), ',',
--                     '"price":', IFNULL(products.price, 0), ',',
--                     '"total_price":', IFNULL(products.price - (products.price * products.discount / 100), 0),
--                 '}'
--             )
--             SEPARATOR ','
--         ),
--         ']'
--     ) AS products_data
-- FROM orders
-- LEFT JOIN cart ON orders.id = cart.order_id
-- INNER JOIN products ON products.id = cart.product_id
-- --WHERE orders.status < 3
-- GROUP BY orders.id;


-- SELECT
-- 	orders.id,
--     orders.status,
--     orders.price,
--     orders.total_price,
-- 	orders.address_id,
-- 	cart.count,
--     products.arabic_name,
--     products.english_name
-- FROM orders
-- LEFT JOIN cart ON orders.id = cart.order_id
-- INNER JOIN products ON products.id = cart.product_id;

CREATE OR REPLACE VIEW product_ratings_view AS
SELECT
    ratings.product_id ,  
    SUM(ratings.star) AS star,
    count(ratings.product_id) AS count
FROM ratings
GROUP BY ratings.product_id;

--// order with user data for admin feature
CREATE OR REPLACE VIEW order_user_view AS
SELECT
    orders.*,

    -- Show either user's or delivery man's name depending on delivery type
    CASE
        WHEN orders.type_delivery = 1 THEN users.username
        WHEN orders.type_delivery = 0 AND orders.delivery_id IS NOT NULL THEN dm.username
        ELSE NULL
    END AS username,

    CASE
        WHEN orders.type_delivery = 1 THEN users.email
        WHEN orders.type_delivery = 0 AND orders.delivery_id IS NOT NULL THEN dm.email
        ELSE NULL
    END AS email,

    CASE
        WHEN orders.type_delivery = 1 THEN users.phone
        WHEN orders.type_delivery = 0 AND orders.delivery_id IS NOT NULL THEN dm.phone
        ELSE NULL
    END AS phone

FROM orders
INNER JOIN users ON orders.user_id = users.id
LEFT JOIN delivery_men dm ON orders.delivery_id = dm.id;


-- 🔹 VIEW 1: Dashboard Counts
-- Counts of users, delivery men, active/inactive products, and total orders
CREATE OR REPLACE VIEW dashboard_counts_view AS
SELECT
    (SELECT COUNT(*) FROM users) AS total_users,
    (SELECT COUNT(*) FROM delivery_men) AS total_delivery_men,
    (SELECT COUNT(*) FROM products WHERE active = TRUE) AS active_products,
    (SELECT COUNT(*) FROM products WHERE active = FALSE) AS inactive_products,
    (SELECT COUNT(*) FROM orders) AS total_orders;

-- 🔹 VIEW 2: Monthly Orders (Line Chart)
-- Total number of orders grouped by month (1 to 12)
CREATE OR REPLACE VIEW monthly_orders_view AS
SELECT
    EXTRACT(MONTH FROM time_create) AS month,
    COUNT(*) AS order_count
FROM orders
GROUP BY month
ORDER BY month;

-- 🔹 VIEW 3: Orders Per City (Bar Chart)
-- Number of orders grouped by city (using address table)

CREATE OR REPLACE VIEW orders_per_city_view AS
SELECT
    order_address.city,
    COUNT(orders.id) AS order_count
FROM orders
JOIN order_address ON order_address.id = orders.address_id
GROUP BY order_address.city
ORDER BY order_count DESC;

-- 🔹 VIEW 4: Product Count by Category (Pie Chart)
-- Count of products grouped by category with Arabic and English names
CREATE OR REPLACE VIEW product_category_pie_view AS
SELECT
    categories.id AS category_id,
    categories.arabic_name,
    categories.english_name,
    COUNT(products.id) AS product_count
FROM products
JOIN categories ON categories.id = products.category_id
GROUP BY categories.id, categories.arabic_name, categories.english_name
ORDER BY product_count DESC;

--//delivery_prepare_order_view
CREATE OR REPLACE VIEW  delivery_prepare_order_view AS
SELECT
    o.id,
	o.price,
    oa.type_address,
    oa.city,
    oa.street,
    oa.detail_address,
    oa.latitude as userLatitude,
    oa.longitude as userLongitude,
    SUM(c.count) AS quantity
FROM orders o
INNER JOIN order_address oa ON oa.id = o.address_id
INNER JOIN cart c ON c.order_id = o.id
WHERE o.status = 1
GROUP BY o.id;

--//delivery accepting order when the order at accept case using in delivery app
CREATE OR REPLACE VIEW order_delivery_view AS
SELECT
    orders.id,
    orders.type_payment,
    orders.price,
    orders.total_price,
    orders.delivery_price,
    orders.status,
    orders.delivery_id,
    orders.user_id,
    users.username,
    users.email,
    users.phone,
    order_address.city,
    order_address.street,
    order_address.type_address,
    order_address.detail_address,
    order_address.latitude,
    order_address.longitude,
    SUM(cart.count) AS quantity 
FROM orders
INNER JOIN users ON orders.user_id = users.id
INNER JOIN order_address ON orders.address_id = order_address.id
INNER JOIN cart ON cart.order_id = orders.id
WHERE orders.status != 0
  AND orders.type_delivery = 0
GROUP BY orders.id;



--///users table 
CREATE TABLE users (
    id INT(11) PRIMARY KEY AUTO_INCREMENT,
    customer_id INT NOT NULL COMMENT 'this for stripe payment',
    username VARCHAR(100) COLLATE utf8_general_ci NOT NULL,
    email VARCHAR(100) COLLATE utf8_general_ci NOT NULL UNIQUE,
    password VARCHAR(20) COLLATE utf8_general_ci NOT NULL,
    phone VARCHAR(15) COLLATE utf8_general_ci UNIQUE,
    verify_code INT(4),
    approve TINYINT(1) DEFAULT 0,
    time_create TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

--///users notification table 
CREATE TABLE users_notification (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
    body VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
    time_create DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    user_id INT(11) NOT NULL,
    INDEX (user_id),
    CONSTRAINT fk_user_id FOREIGN KEY (user_id)
        REFERENCES users(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);


--/// category table
CREATE TABLE categories (
    id INT(11) PRIMARY KEY AUTO_INCREMENT,
    arabic_name VARCHAR(255) COLLATE utf8_general_ci NOT NULL,
    english_name VARCHAR(255) COLLATE utf8_general_ci NOT NULL,
    image VARCHAR(255) COLLATE utf8_general_ci NOT NULL,
    time_create TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

--/// product table 
CREATE TABLE products (
    id INT(11) PRIMARY KEY AUTO_INCREMENT,
    arabic_name VARCHAR(255) COLLATE utf8_general_ci NOT NULL,
    english_name VARCHAR(255) COLLATE utf8_general_ci NOT NULL,
    arabic_description TEXT COLLATE utf8_general_ci,
    english_description TEXT COLLATE utf8_general_ci,
    image VARCHAR(255) COLLATE utf8_general_ci NOT NULL,
    count INT(11) NOT NULL,
    active TINYINT(1) DEFAULT 1,
    price DOUBLE(10, 2) NOT NULL,
    discount DOUBLE(10, 2) NOT NULL,
    time_create TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

---/// cart table
CREATE TABLE cart (
    id INT(11) PRIMARY KEY,
    users_id INT(11),
    product_id INT(11),
    count INT(11) DEFAULT 1,
    INDEX(users_id),
    INDEX(product_id),
    FOREIGN KEY (users_id) REFERENCES users(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);


---/// address table 
CREATE TABLE address (
    id INT(11) NOT NULL AUTO_INCREMENT,
    type_address VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
    city VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
    street VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
    detail_address TEXT CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
    latitude DOUBLE NOT NULL,
    longitude DOUBLE NOT NULL,
    user_id INT(11) NOT NULL,
    PRIMARY KEY (id),
    INDEX (user_id),
    FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

CREATE TABLE order_address ( 
    id INT(11) NOT NULL AUTO_INCREMENT, 
    type_address VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, 
    city VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, 
    street VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, 
    detail_address TEXT CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL, 
    latitude DOUBLE NOT NULL, longitude DOUBLE NOT NULL, 
    user_id INT(11) NOT NULL, PRIMARY KEY (id), 
    INDEX (user_id), 
    FOREIGN KEY (user_id) REFERENCES users(id) 
        ON DELETE CASCADE 
        ON UPDATE CASCADE 
);

--query using to insert form address table to order_address table
INSERT INTO order_address (type_address, city, street, detail_address, latitude, longitude, user_id)
        SELECT type_address, city, street, detail_address, latitude, longitude, user_id
        FROM `address`
        WHERE id = ? AND user_id = ?

--///coupons table
CREATE TABLE coupons (
    id INT(11) NOT NULL AUTO_INCREMENT,
    name VARCHAR(20) NOT NULL UNIQUE,
    amount INT(11) NOT NULL,
    count SMALLINT(6) NOT NULL,
    expiry_data DATETIME,
    PRIMARY KEY (id)
);

--///check_users_coupons table
CREATE TABLE `check_users_coupons` (
    `id` INT(11) NOT NULL AUTO_INCREMENT,
    `user_id` INT(11) NOT NULL,
    `coupons_id` INT(11) NOT NULL,
    PRIMARY KEY (`id`),
    -- Foreign key to users table
    CONSTRAINT `fk_check_user` FOREIGN KEY (`user_id`)
        REFERENCES `users` (`id`)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    -- Foreign key to coupons table
    CONSTRAINT `fk_check_coupon` FOREIGN KEY (`coupons_id`)
        REFERENCES `coupons` (`id`)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);


--//order table
CREATE TABLE orders (
    id INT(11) NOT NULL AUTO_INCREMENT,
    type_payment TINYINT(1) NOT NULL COMMENT '0 => cash, 1 => card',
    type_delivery TINYINT(1) NOT NULL COMMENT '0 => delivery, 1 => receive',
    delivery_price DOUBLE NOT NULL DEFAULT 0 COMMENT '0 => receive',
    price DOUBLE NOT NULL,
    total_price DOUBLE NOT NULL,
    coupons INT(11) NOT NULL DEFAULT 0,
    status TINYINT(4) NOT NULL DEFAULT 0, COMMENT '0=>pendding, 1=>proper, 2=>delivery accept, 3=>on the way, 4=>done',
    time_create DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    user_id INT(11) NOT NULL,
    address_id INT(11) DEFAULT NULL COMMENT 'null => receive',
    PRIMARY KEY (id),
    INDEX (user_id),
    INDEX (address_id),
    CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES users(id),
    CONSTRAINT fk_address FOREIGN KEY (address_id) REFERENCES address(id)
);


--//ratings table 
CREATE TABLE ratings (
    id INT(11) PRIMARY KEY AUTO_INCREMENT,
    star TINYINT(4) NOT NULL,
    comment VARCHAR(255) COLLATE utf8_general_ci NOT NULL,
    product_id INT(11) NOT NULL,
    order_id INT(11) NOT NULL,
    user_id INT(11) NOT NULL,
    FOREIGN KEY (product_id) REFERENCES products(id),
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    INDEX (product_id),
    INDEX (order_id),
    INDEX (user_id)
);


--// admains table
CREATE TABLE admins (
    id INT(11) PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_general_ci,
    email VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_general_ci,
    password VARCHAR(20) CHARACTER SET utf8 COLLATE utf8_general_ci,
    phone VARCHAR(15) CHARACTER SET utf8 COLLATE utf8_general_ci UNIQUE,
    verify_code INT(4),
    approve TINYINT(1) NOT NULL DEFAULT 0,
    -- authority TINYINT(4) NOT NULL,
    time_create TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);


--//admins notification 
CREATE TABLE admins_notification (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
    body TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
    recipient TINYINT(1) NOT NULL DEFAULT 0 COMMENT '0 => admin_receive, 1 => users, 2 => delivery',
    time_create DATETIME DEFAULT CURRENT_TIMESTAMP,
    user_id INT(11) NOT NULL,
    INDEX (user_id),
    CONSTRAINT fk_user_id FOREIGN KEY (user_id)
        REFERENCES admins(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);



--// delivery men table
CREATE TABLE delivery_men (
    id INT(11) PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
    email VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL UNIQUE,
    password VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
    phone VARCHAR(20) CHARACTER SET utf8 COLLATE utf8_general_ci UNIQUE,
    verify_code INT(4) NOT NULL,
    approve TINYINT(1) NOT NULL DEFAULT 0,
    available TINYINT(1) NOT NULL DEFAULT 1 COMMENT '1 => available, 0 => unavailable',
    active TINYINT(1) NOT NULL DEFAULT 0 COMMENT '0 => inactive, 1 => active',
    time_create TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);


--delivery men notification table 
CREATE TABLE delivery_men_notification (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
    body TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
    time_create DATETIME DEFAULT CURRENT_TIMESTAMP,
    user_id INT(11) NOT NULL,
    INDEX (user_id),
    CONSTRAINT fk_user_id FOREIGN KEY (user_id)
        REFERENCES delivery_men(id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);
