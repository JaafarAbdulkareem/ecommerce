<?php

    require __DIR__ . '/../../vendor/autoload.php'; // Ensure only one autoload is included
    use Google\Auth\Credentials\ServiceAccountCredentials;
    
    function sendFCMMessage($topic, $title, $body, $pageid, $pagename, $imageUrl = null,$data = null) {
        $projectId = "ecommerce-41619";
        
        // Update the path to server_key.json
        $serverKey = __DIR__ . '/server_key.json'; // Corrected path
    
        try {
            // Check if the server key file exists
            if (!file_exists($serverKey)) {
                throw new Exception("Server key file not found: " . $serverKey);
            }
    
            // Fetch the server key content
            $serverKeyContents = file_get_contents($serverKey);
            if ($serverKeyContents === false) {
                throw new Exception("Unable to read the server key file: " . $serverKey);
            }
    
            // Decode the server key JSON
            $serverKeyJson = json_decode($serverKeyContents, true);
            if ($serverKeyJson === null) {
                throw new Exception("Invalid JSON format in the server key file.");
            }
    
            // Create service account credentials from JSON key file
            $credential = new ServiceAccountCredentials(
                "https://www.googleapis.com/auth/firebase.messaging",
                $serverKeyJson
            );
    
            // Fetch authentication token
            $token = $credential->fetchAuthToken();
            if (!$token) {
                throw new Exception("Failed to fetch authentication token.");
            }
    
            // Set up cURL request to send the message
            $ch = curl_init("https://fcm.googleapis.com/v1/projects/$projectId/messages:send");
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json',
                'Authorization: Bearer ' . $token['access_token'],
            ]);
    
            // Prepare the message
            $message = [
                'message' => [
                    "topic" => $topic,
                    'notification' => [
                        'title' => $title,
                        'body' => $body,
                    ],
                    'data' => array_merge([
                        "pageid" => $pageid ?? '',
                        "pagename" => $pagename ?? ''
                    ], is_array($data) ? $data : [])
                ],
            ];
    
            if ($imageUrl) {
                $message['message']['notification']['image'] = $imageUrl;
            }
    
            // Send the message via cURL
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($message));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    
            // Execute cURL request
            $response = curl_exec($ch);
    
            if (curl_errno($ch)) {
                throw new Exception("Curl error: " . curl_error($ch));
            }
    
            curl_close($ch);
            return $response;
    
        } catch (Exception $e) {
            error_log("Error sending FCM message: " . $e->getMessage());
            return $e->getMessage();
        }
    }
  
?>