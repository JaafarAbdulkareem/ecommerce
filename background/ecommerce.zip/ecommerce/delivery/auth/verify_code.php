<?php
    include "../../connect.php";
    $table = 'delivery_men';

    $email = filterRequest("email");
    $verifyCode = filterRequest("verifyCode");
    
    $stmt = $con->prepare("SELECT  * FROM $table WHERE `email` = ? AND `verify_code` = ? AND `approve` = ? ");
    $stmt->execute(array($email,$verifyCode,0));
    $count  = $stmt->rowCount();
    if ($count > 0) {
        $stmt = $con->prepare("UPDATE $table SET `approve` = 1 WHERE `email` = ? ");
        $stmt->execute(array($email));
        echo json_encode(array("status" => "success"));
    } else {
        echo json_encode(array("status" => "failure"));
    }
?>