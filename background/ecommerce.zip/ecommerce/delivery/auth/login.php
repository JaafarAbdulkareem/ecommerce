<?php
    include "../../connect.php";
    include '../notification/send_message.php';

    $table = "delivery_men";
    $email = filterRequest("email");
    $password = filterRequest("password");
    $approve = 1;
    
    $data = returnData($table, "`email` = ? AND `password` = ?", [$email,$password]);
 
    if (!empty($data) || $data != null){
        if($data["approve"] == $approve){
            echo json_encode(array("status" => "success","data" => $data));
        }else{
            $verifyCode = rand(1000,9999);
            $stmt = $con->prepare("UPDATE $table SET `verify_code` = ? WHERE `email` = ? AND `password` = ?");
            $stmt->execute(array($verifyCode,$email,$password));
            $deliveryTitle = "OTP";
            $deliveryMessage = "Your OTP is: {$verifyCode}";
            sendFCMMessage(
                "delivery_men",
                $deliveryTitle,
                $deliveryMessage,
                null,
                null,
            );
            echo json_encode(array("status" => "failure","data" => "noApprove"));

        }
    } else {
        echo json_encode(array("status" => "failure","data" => "noFound"));
    }
    
    
    
    
?>