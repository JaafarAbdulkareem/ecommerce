<?php
    include "../../connect.php";

    $table = "order_delivery_view";

    $deliveryId = filterRequest("deliveryId");
    $status = 2;
    getAllData($table,"`status` = ? AND `delivery_id` = ?",[$status,$deliveryId]);
?>