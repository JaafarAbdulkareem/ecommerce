<?php
    include "../../connect.php";

    $table = "order_delivery_view";
    
    $deliveryId = filterRequest("deliveryId");
    $status = 3;
    getAllData($table,"`status` = ? AND `delivery_id` = ?",[$status,$deliveryId]);
?>