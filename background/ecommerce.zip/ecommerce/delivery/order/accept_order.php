<?php
    include "../../connect.php";
    include '../notification/send_message.php';

    $table = "orders";
    $id = filterRequest("id");
    $status = 2;
    $userId = filterRequest("userId");
    $deliveryId = filterRequest("deliveryId");
    $deliveryName = filterRequest("deliveryName");
    $deliveryEmail = filterRequest("deliveryEmail");
    $deliveryPhone = filterRequest("deliveryPhone");
    $adminId = "1";

    $data = array(
        "status" => $status,
        "delivery_id" => $deliveryId,
    );

    $where = "`id` = $id AND `user_id` = $userId AND `status` = 1 AND `type_delivery` = 0";
    $count = updateData($table, $data, $where, false);

    if ($count > 0) {
    //admin notification 
        $adminTitle = "Delivery Accepted";
        $adminMessage =  "🚚 Delivery  #$deliveryId ($deliveryName) has accepted the order."; 
        $dataAdminNotification = array(
            "title"   => $adminTitle,
            "body"    => $adminMessage,
            "user_id" => $adminId,
        );
        sendFCMMessage(
            "admins",
            $adminTitle,
            $adminMessage,
            "idAcceptedPage",
            null,
            null,
            array(
                "id" => $id,
                "deliveryName" => $deliveryName,
                "deliveryEmail" => $deliveryEmail,
                "deliveryPhone" => $deliveryPhone
            )
        );
        insertData("admins_notification", $dataAdminNotification,false);

        $where = "`id` = $id AND `user_id` = $userId AND `delivery_id` IS NULL";
        updateData($table, ["delivery_id" => $deliveryId], $where, false);

        echo json_encode(array("status" => "success"));
    } else {
        echo json_encode(array("status" => "failure"));
    }
?>
